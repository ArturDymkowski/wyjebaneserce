<?php


namespace PrestaShop\PrestaShop\Tests\Unit;


use PHPUnit_Framework_TestCase;

class DummyTest extends PHPUnit_Framework_TestCase
{

    public function testDummy()
    {
        $this->assertTrue(true, 'Everything works fine');
    }
}
